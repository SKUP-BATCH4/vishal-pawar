#include<stdio.h>
int ar()
{
int a,b;
printf("Enter theb ele:");
scanf("%d%d",&a,&b);
a=a%16;
b=b%16;
for(int i=0;i<8;i++)
{
if(a[7]==0)
{
printf("Msg w");
}
else
{
printf("m l");
}

for(int i=0;i<8;i++)
{

}
}
