#include<stdio.h>
int main()
{
    int a=20;
    ++a;
    printf("%d\n",a++);
     printf("%d",++a);
}

